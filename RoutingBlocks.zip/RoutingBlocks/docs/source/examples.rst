Examples
====================

* `ils <https://github.com/tumBAIS/RoutingBlocks/tree/main/examples>`_: A simple ILS for the EVRP-TW-PR.
* `alns <https://github.com/tumBAIS/RoutingBlocks/tree/main/examples>`_: A simple ALNS for the EVRP-TW-PR.
* `evrptw <https://github.com/tumBAIS/RoutingBlocks/tree/main/examples>`_: An example implementation of a more sophisticated ALNS-based algorithm for the EVRP-TW-PR problem.
* `cvrp <https://github.com/tumBAIS/routingblocks-native-extension-example>`_: Example of a native extension to solve the CVRP.
